export interface Product {
  id: string | number;
  name: string;
  price: string | number;
  barcode: string;
}

export interface SqlConfig {
  user: string;
  password?: string;
  server: string;
  database: string;
  options?: {
    encrypt?: boolean;
    trustServerCertificate?: boolean;
  };
}

export interface AppConfig {
  shopName: string;
  sql: SqlConfig;
  table: string;
  columnMapping: {
    name: string;
    price: string;
    barcode: string;
  };
}
