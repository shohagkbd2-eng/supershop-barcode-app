import express from "express";
import { createServer as createViteServer } from "vite";
import sql from "mssql";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // SQL Server Connection API
  app.post("/api/fetch-data", async (req, res) => {
    const { config, table, columns } = req.body;

    if (!config || !table || !columns || columns.length < 3) {
      return res.status(400).json({ error: "Missing configuration or columns" });
    }

    try {
      // Connect to SQL Server with timeout
      const pool = await sql.connect({
        ...config,
        connectionTimeout: 15000, // 15 seconds
        requestTimeout: 15000,
      });
      
      // Select the 3 specified columns
      const query = `SELECT TOP 100 ${columns.join(", ")} FROM ${table}`;
      const result = await pool.request().query(query);
      
      await pool.close();
      
      res.json({ data: result.recordset });
    } catch (err: any) {
      console.error("SQL Error:", err);
      res.status(500).json({ error: err.message || "Failed to connect to SQL Server" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
